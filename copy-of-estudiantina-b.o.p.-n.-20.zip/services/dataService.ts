
import { Score } from '../types';

// No initial scores, starting from a clean slate for the real event.
export const MOCK_INITIAL_SCORES: Score[] = [];